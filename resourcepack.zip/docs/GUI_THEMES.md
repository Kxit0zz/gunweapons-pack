# Fonds d'apercu personnalises par crate (CratesCasino)

## Principe

Minecraft ne permet pas nativement d'avoir une texture de fond differente par menu
(le fond d'un coffre double est toujours `textures/gui/container/generic_54.png`,
partage par TOUS les inventaires de ce type, quel que soit le plugin).

Pour avoir un visuel different par caisse (comme demande), on utilise la technique
standard employee par les gros plugins de crates commerciaux : une **police de
caracteres custom** ou chaque caractere prive correspond a une image. Le TITRE de
l'inventaire (visible en haut du menu) est rempli avec ce caractere : le jeu affiche
alors l'image a la place d'un texte normal, et comme elle est bien plus grande qu'une
ligne de texte classique, elle s'etend vers le bas et recouvre visuellement la zone
des slots. Les items (recompenses) sont ensuite dessines PAR-DESSUS cette image,
normalement, a leur emplacement de slot habituel : aucune texture d'item n'est
affectee, seul le fond change.

C'est exactly ce que fait `PreviewGUI` maintenant : si une crate a un theme
different de "Aucun", le titre de l'inventaire devient un caractere de la police
`cratescasino:crates_gui` au lieu du texte "Apercu - <nom>".

## Fichiers

- `assets/cratescasino/font/crates_gui.json` : declare 8 "bitmap providers" (un par
  theme) + un provider `space` pour caler horizontalement l'image sur le bord
  gauche du menu.
- `assets/cratescasino/textures/gui/crates/bg_*.png` : les 8 images de fond
  (352x280 px, soit une resolution 2x pour rester nette). Ce sont des **versions de
  depart** generees pour matcher les couleurs de ta maquette (gris/argent pour
  Commune, cyan pour Rare, violet pour Epique, or pour Mythique, rouge sombre pour
  Ultime, orange pour KOTH, rouge/noir pour Armes, bleu pour Cles) : a toi de les
  remplacer par un vrai design si tu veux coller pixel pres a ta maquette d'origine
  (meme nom de fichier, meme dimensions ou proportion 352x280 = ratio 176x140).

## Les chiffres (et pourquoi)

Le panneau d'un coffre double (`generic_9x6`) fait **176 px de large**, et la zone
des slots fait 6 rangees x 18 px = **108 px de haut**, en commencant a peu pres a
**18 px du haut** du menu. J'ai donc construit les images sur une grille ou, une
fois affichees a `height: 140` (dans le json), elles font exactement :

- 18 px de bandeau d'en-tete
- 108 px de zone de grille (6 x 18 px, alignee sur la taille reelle d'un slot)
- 14 px de bandeau de pied (comme le bandeau sombre en bas de ta maquette)

`ascent: 13` est une valeur de depart calculee pour faire correspondre le haut de
l'image au coin superieur gauche du menu (le texte du titre demarre normalement
quelques pixels plus bas). Le caractere invisible `\uF001` (provider `space`,
avance -8) sert a ramener le curseur sur le bord gauche du menu avant de dessiner
l'image (le titre demarre normalement avec une petite marge de 8 px).

## Ce qui va probablement demander un reglage fin en jeu

Le calcul ci-dessus est correct sur le papier (constantes officielles du GUI
vanilla), mais Minecraft n'expose pas de mode "regle millimetre" pour ca : il n'y a
pas moyen de le verifier sans le voir tourner en jeu. Concretement :

1. Recharge le resource pack et ouvre l'apercu d'une crate avec un theme.
2. Si l'image est un peu trop haute/basse ou trop a gauche/droite par rapport aux
   items :
   - Decale verticalement : modifie `ascent` (plus grand = image plus haute a
     l'ecran, sur les 8 fonds a la fois puisqu'ils partagent le meme calage) par
     pas de 2-3.
   - Decale horizontalement : modifie l'avance de `\uF001` (plus negatif = image
     plus a gauche) par pas de 1-2.
3. Recharge le resource pack (pas besoin de redemarrer le serveur ni de recompiler
   le plugin, seul le fichier `.json` change) et recompare.

Une fois le bon reglage trouve pour un theme, il est identique pour les 8 (ils
partagent tous `ascent`/les memes espaces de calage), donc un seul essai suffit
pour valider le calage geometrique — ensuite tu peux changer librement le contenu
graphique de chaque PNG sans retoucher le json.

## Utilisation en jeu

- `/crates edit <crate>` -> bouton "Theme visuel de l'apercu" (icone tableau),
  clic pour faire defiler les 9 valeurs (Aucun + les 8 themes).
- `/crates settheme <crate> <theme>` -> assigner directement (tab-completion
  disponible). Themes : `commune`, `rare`, `epique`, `mythique`, `ultime`, `koth`,
  `armes`, `cles`, ou `none` pour revenir au menu par defaut.
- Meme sans le resource pack installe, le menu reste utilisable : une bordure en
  vitre teintee de la couleur du theme s'affiche en filet de securite (100%
  vanilla), et l'icone/le nom de la crate restent lisibles au centre du bandeau du
  haut.
