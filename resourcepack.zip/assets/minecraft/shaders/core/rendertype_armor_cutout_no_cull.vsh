#version 150

// LUWA - armures personnalisees (1.21.1)
// leather_layer_1/2.png contiennent 16 images de 128x64 cote a cote :
// image 0 = cuir vanilla, image N = set LUWA dont la couleur de teinture vaut (N, 1, 2).

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const int FRAMES = 16;

vec4 luwaMixLight(vec3 lightDir0, vec3 lightDir1, vec3 normal, vec4 color) {
    lightDir0 = normalize(lightDir0);
    lightDir1 = normalize(lightDir1);
    float light0 = max(0.0, dot(lightDir0, normal));
    float light1 = max(0.0, dot(lightDir1, normal));
    float lightAccum = min(1.0, (light0 + light1) * 0.6 + 0.4);
    return vec4(color.rgb * lightAccum, color.a);
}

float luwaFogDistance(vec3 pos, int shape) {
    if (shape == 0) {
        return length(pos);
    }
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexDistance = luwaFogDistance(Position, FogShape);

    vec4 color = Color;
    vec2 uv = UV0;
    ivec2 size = textureSize(Sampler0, 0);
    if (size.x == size.y * 2 * FRAMES) {
        ivec3 c = ivec3(round(Color.rgb * 255.0));
        int frame = 0;
        if (c.g == 1 && c.b == 2 && c.r > 0 && c.r < FRAMES) {
            frame = c.r;
            color = vec4(1.0, 1.0, 1.0, Color.a);
        }
        uv.x = (uv.x + float(frame)) / float(FRAMES);
    }

    vertexColor = luwaMixLight(Light0_Direction, Light1_Direction, Normal, color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = uv;
}
